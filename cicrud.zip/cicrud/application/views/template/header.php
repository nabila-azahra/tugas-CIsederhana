<html>
    <head>
        <title>Belajar MVC di COdeIgniter</title>
    </head>
<body>
<h1><?php echo $judul?></h1>
